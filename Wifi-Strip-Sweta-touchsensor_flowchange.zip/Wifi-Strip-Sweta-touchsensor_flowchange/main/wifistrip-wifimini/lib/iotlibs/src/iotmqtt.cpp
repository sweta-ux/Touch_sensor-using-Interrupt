/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#include "iotmqtt.h"

iotdevice::iotdevice() {}

iotdevice::iotdevice(const char *project_id,const char *location,const char *registry_id,const char *device_id,const char *private_key) {
  setProjectId(project_id);
  setLocation(location);
  setRegistryId(registry_id);
  setDeviceId(device_id);
  setPrivateKey(private_key);
}

unsigned long iotdevice::getExpMillis() {
  return exp_millis;
}

int iotdevice::getJwtExpSecs() {
  return jwt_exp_secs;
}

String iotdevice::createJWT(long long int current_time, int exp_in_secs) {
  jwt_exp_secs = exp_in_secs;
  exp_millis = millis() + (jwt_exp_secs * 1000);
  jwt = CreateJwt(project_id, current_time, priv_key, exp_in_secs);
  return jwt;
}

String iotdevice::getJWT() { 
  return jwt;
}

String iotdevice::getClientId(){
  return String("projects/") + project_id + "/locations/" + location +"/registries/" + registry_id + "/devices/" + device_id;
}

/**
 * Commands subscription topic name
 */
String iotdevice::getCommandsTopic(){
  return String("/devices/") + device_id + "/commands/#";
}

/**
 * Cofig subscription topic name
 */
String iotdevice::getConfigTopic(){
  return String("/devices/") + device_id + "/config";
}

/**
 * publish topic name
 */
String iotdevice::getEventsTopic(){
  //return String("/projects/smart-strip/topics/telemetry");
  return String("/devices/") + device_id + "/events";
  //return String("/devices/") + device_id + "/telemetry";
}

String iotdevice::getStateTopic(){
  return String("/devices/") + device_id + "/state";
}

/*String iotdevice::getvc_configTopic(){
  return String("/devices/") + device_id + "/vcconfig";
}*/


void iotdevice::setJwtExpSecs(int exp_in_secs) {
  this->jwt_exp_secs = exp_in_secs;
}

iotdevice &iotdevice::setProjectId(const char *project_id) {
  this->project_id = project_id;
  return *this;
} 

iotdevice &iotdevice::setLocation(const char *location) {
  this->location = location;
  return *this;
}

iotdevice &iotdevice::setRegistryId(const char *registry_id) {
  this->registry_id = registry_id;
  return *this;
}

iotdevice &iotdevice::setDeviceId(const char *device_id) {
  this->device_id = device_id;
  return *this;
}

iotdevice &iotdevice::setPrivateKey(const char *private_key) {
  if (strlen(private_key) != (95)) {
    //Serial.println("Warning: expected private key to be 95, was: " + String(strlen(private_key)));
  }
  priv_key[8] = 0;
  for (int i = 7; i >= 0; i--) {
    priv_key[i] = 0;
    for (int byte_num = 0; byte_num < 4; byte_num++) {
      priv_key[i] = (priv_key[i] << 8) + strtoul(private_key, NULL, 16);
      private_key += 3;
    }
  }
  return *this;
}

String getJwt();
void message_received(String &topic, String &payload);

iotmqtt::iotmqtt(
    MQTTClient *_mqttClient, Client *_netClient, iotdevice *_device){
  this->mqttClient = _mqttClient;
  this->netClient = _netClient;
  this->device = _device;
}

boolean iotmqtt::loop() {
  if (millis() > device->getExpMillis() && mqttClient->connected()) {
    // reconnect
    mqttClient->disconnect();
  }
  return this->mqttClient->loop();
}

bool iotmqtt::publishTelemetry(String data) {
  return this->mqttClient->publish(device->getEventsTopic(), data);
}

bool iotmqtt::publishState(const String &data) {
  return this->mqttClient->publish(device->getStateTopic(), data);
}

/*bool iotmqtt::publish_vc_config(const String &data) {
  return this->mqttClient->publish(device->getvc_configTopic(), data);
}*/

bool iotmqtt::publishonsubtopic(String subtopic, String data) {
  return this->mqttClient->publish(device->getEventsTopic() + subtopic, data);
}
void iotmqtt::setLogConnect(boolean enabled) {
  this->logConnect = enabled;
}

void iotmqtt::setUseLts(boolean enabled) {
  this->useLts = enabled;
}
