#include <WebServer.h>
#include <WiFi.h>
#include <ArduinoJson.h>
#include "server_response.h"
#include "MD5.h"
#include "cloud.h"
#include "apmode.h"
#include "soc/timer_group_struct.h"
#include "soc/timer_group_reg.h"

WebServer offline_server(8888);
extern int cmd;

/**
 * handle_offline_server:- handling offline client of device 
 * ret:- void
 * args:- void
 */
void handle_offline_server(void *pvParameters) {
  for(;;) {
    offline_server.handleClient();
  }
}

/**
 * create_md5:- creating md5 from ap_mode and ip address of the device
 * ret:- char *
 * args:- void
 */
char * create_md5 (void) {
  char qwas[25];
  String ip = check_ip();
  String ap_mac = six_digit_mac();
  String adc = ap_mac + String("_") + String(ip);
  adc.toCharArray(qwas, 25);
  //char *qwas = String(qwas);
  unsigned char* hash = MD5::make_hash(qwas);
  //generate the digest (hex encoding) of our hash
  char *md5str = MD5::make_digest(hash, 16);
  //print it on our serial monitor
  return md5str;
}

/**
 * handle_post_request:- handling post request from device
 * ret:- void
 * args:- void
 */
void handle_post_request(void) {
  if (offline_server.hasArg("plain") == false) {
    //handle error here
  }
  String body = offline_server.arg("plain");
  Serial.println(body);
  StaticJsonBuffer<2000> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(body);
  if (!root.success()) {
    Serial.println("JSON NOT VALID");
  }
  int cmd = root["cmd"];
  const char *md5 = root["md5"];
  char *MD5 = create_md5(); /* before procedding ahead check md5 */
  JsonObject& offline_json = jsonBuffer.createObject();
  offline_json["version"] = String(code_version);
  //String md = root["md5"];
  if (strcmp(md5, MD5) == 0) {
    String random_string = (const char*)root["commandId"];
    String peripherals = root["peripheral"];
    int version = root["version"];
    bool debug = root["debug"];
    bool online = false;
    check_cmd(cmd, peripherals, "url", "weather", "action", version, debug, online);
    offline_json["status"] = "0";
    offline_json["msg"] = "succes";
    if (version == code_version) {
      String data = relays_response(false, periodic_cmd, false);
      publish_on_periodic(data);
      PRINTR(data);
    }
  } else {
    offline_json["msg"] = "Invalid json";
    offline_json["status"] = "1";
  }
  String response;
  offline_json.printTo(response);
  offline_server.send(200, "application/json", response);
}

/**
 * setup_routing:- setup routing of the offline api
 * ret:- void
 * args:- void
 */
void setup_routing(void) {
  offline_server.on("/command", HTTP_POST, handle_post_request);    
  // start server    
  offline_server.begin();
}
