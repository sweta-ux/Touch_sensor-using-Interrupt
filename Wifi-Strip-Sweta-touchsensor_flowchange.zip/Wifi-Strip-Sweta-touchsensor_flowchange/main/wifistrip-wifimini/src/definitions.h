/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef DEFINITION_H
#define DEFINITION_H

/* Defining the project name */

#define NTP
#define LOGS
/************** WIFISTRIP **************/
//#define WIFISTRIP
//#define WIFIPLUG
//#define OLED
//#define WIFISTRIP_PINS
//#define WIFISTRIP_NUM_RELAYS
//#define WIFISTRIP_AP_MODE

/************** WIFIMINI **************/
//#define WIFIMINI
//#define WIFIMINI_AP_MODE
//#define WIFIMINI_PINS
//#define WIFIMINI_NUM_RELAYS
//#define HARD_RESET
//#define WIFIMINI_AC_SWITCH

/************** WIFIMINI_8_RELAY **************/
//#define WIFIMINI_8_RELAY
//#define WIFISTRIP_8_NUM_RELAYS
//#define WIFIMINI_8_RELAY_AP_MODE

/************** WIFIPLATE **************/
#define WIFIPLATE
#define WIFIPLATE_PINS
#define WIFIPLATE_AP_MODE
#define WIFIPLATE_NUM_RELAYS
#define WIFIPLATE_TOUCH_PIN
//#define WIFIPLATE_TACT_PIN

//#define WIFIPLUG
//#define WIFIPLUG_NUM_RELAYS
//#define WIFIPLUG_AP_MODE

/************** POWER MEASUREMENT **************/
//#define POWER_MEASUREMENT
//#define WIFIMINI_POWER_AP_MODE
//#define WIFISTRIP_POWER_AP_MODE

/************** AP_MODE NAME **************/
#ifdef WIFISTRIP_AP_MODE
#define ap_mode "VCAUTO_001_"
#endif

#ifdef WIFIPLUG_AP_MODE
#define ap_mode "VCAUTO_002_"
#endif

#ifdef WIFIMINI_AP_MODE
#define ap_mode "VCAUTO_003_"
#endif

#ifdef WIFISTRIP_POWER_AP_MODE
#define ap_mode "VCAUTO_004_"
#endif

#ifdef WIFIMINI_POWER_AP_MODE
#define ap_mode "VCAUTO_005_"
#endif

#ifdef WIFIMINI_8_RELAY_AP_MODE
#define ap_mode "VCAUTO_006_"
#endif

#ifdef WIFIPLATE_AP_MODE
#define ap_mode "VCAUTO_007_"
#endif

/* Debugging switches and macros
 Switch debug output on and off by 1 or 0 */
#define DEBUG 1

#if DEBUG
#define PRINTS(...) Serial.print(__VA_ARGS__)
#define PRINTR(...) {Serial.println(__VA_ARGS__);}//Serial.println(__func__);}
#else
#define PRINTS(s)
#define PRINTR(s)
#endif

#define relay_onn 1
#define relay_off 0
#define DELAY_100 delay(100);
#define DELAY_5000 delay(50)
#define DELAY_200 delay(200)
#define DELAY_300 delay(300)
#define DELAY_1000 delay(1000)
#define DELAY_2000 delay(2000)
#define DELAY_60000 delay(60000)

#define SUCCESS 0
#define FAILURE 1

/************** PINS DESCRIPTION **************/
#ifdef WIFISTRIP_NUM_RELAYS
#define NUM_RELAYS 4
#endif

#ifdef WIFIMINI_NUM_RELAYS
#define NUM_RELAYS 4
#endif

#ifdef WIFIMINI_8_NUM_RELAYS
#define NUM_RELAYS 8
#endif

#ifdef WIFIPLATE_NUM_RELAYS
#define NUM_RELAYS 4
#endif

#ifdef WIFIPLUG_NUM_RELAYS
#define NUM_RELAYS 1
#endif

/* ERROR CODES */
#define hardware_error "ERHW" /* HARDWRAE ERROR */
#define memory_error "ERMM" /* MEMORY ERROR */
#define no_data_in_nv "ERNV" /* NO DATA */
#define reset_device    "RST" /* RESET DEVICE */
#define invalid_json "ERIJ" /* INVALID JSON */
#define please_wait "WAIT" /* CLEAR NV */

/* OLED NOTIFICATION FOR USER */
#define start_msg "HELLO"
#define server_mode "CONFIG..."
#define wifi_connect "WAITING..."
#define wifi_connecting "CONNECTING..."
#define mqtt_disconnect "ERR01" /* Mqtt Not connect */

/* MAX TIME FOR SENDING PERIODIC DATA */
#define max_sending_time 360000  /* SEDNING JSON TIME FOR TESTING */
//#define max_sending_time 600000 /* SEDNING JSON TIME FOR TESTING */

#define data_file "/data.txt"
#define log_file  "/log.txt"

#define code_version 102

#define code_sha ""

/* cmd status for response */
#define response_cmd 2
#define periodic_cmd 3
#define device_cmd 4
#define state_cmd 5
#define device_delete 6

/**
 * cloud - define the structure for cloud configuration
 */
struct cloud_def {
  const char *wifi_ssid;
  const char *wifi_pass;
  const char *cloud_project_id;
  const char *cloud_location;
  const char *cloud_device_id;
  const char *cloud_private_key;
  const char *cloud_registry_id;
};

#endif